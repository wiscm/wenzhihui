# 🪶 文智汇 — 文献智能数据获取系统

> 一键启动的本地 AI 文献工作站：检索 → 下载 → AI 阅读 → 数据提取，全流程自动化。

## 📋 系统要求

- Windows 10 / 11（64 位）
- 网络（首次安装依赖时需要）
- 约 600 MB 磁盘空间（Anaconda + Python 环境）

---

## 🚀 三步上手（零基础也能用）

### 第 1 步：安装 Anaconda

如果你的电脑**没有** Anaconda，先下载安装：

1. 访问 **https://www.anaconda.com/download**
2. 下载 **Windows 64-Bit** Graphical Installer
3. 运行安装程序
4. ⚠️ **关键**：安装时勾选 `Add Anaconda3 to my PATH environment variable`

> 如果你电脑里已经有 Anaconda / Miniconda，可以跳过这步。

### 第 2 步：解压本压缩包

解压 `文智汇_v1.0.zip` 到任意目录，**建议路径不要有中文**，例如：
```
D:\文智汇\
D:\tools\wenzhihui\
```

### 第 3 步：双击启动

- **首次使用**：双击 `首次安装并启动.bat`
  - 自动创建 Python 环境、安装依赖（约 5–15 分钟）
  - 自动打开浏览器到 `http://127.0.0.1:8501`
- **后续使用**：直接双击 `启动.bat`（秒开）

---

## ✨ 功能一览

### ① 批量检索文献 + AI 速读
- **🤖 AI 智能检索助手**：用自然语言描述需求，AI 多轮对话确认检索方案
- 跨 **5 大公开数据源**：arXiv、PubMed-PMC、Semantic Scholar、OpenAlex、中文库
- 关键词 / 作者 / 期刊 三种检索类型，含**期刊中科院分区**标注
- **多关键词彩色高亮**命中位置
- **中英双语**：输入中文自动翻译检索国际库；输入英文自动检索中文库
- **历史去重**：同一关键词组之前出现过的文献自动隐藏

### ② 下载文献与支撑材料
- 一键批量下载开放获取（OA）的 PDF 到 `data/pdfs/`
- 自动下载 PMC 支撑材料（ZIP 含补充表格）到 `data/supplementary/`
- 支撑材料中的表格可一键导入 Excel

### ③ AI 阅读与数据提取
- **📊 数据关键词**：指定关注的量化指标（如"拉伸强度、硬度"），AI 优先完整提取
- **领域模板**：材料学 / 能源电池 / 化学催化 / 生物医学 / 物理电子 / 通用数值
- **📌 支撑材料线索**：自动检测正文对 Table S1 / Supporting Information 等的引用
- 即使没有 PDF 也可用：自动回退到 PMC 开放全文或摘要
- **批量模式**：一键处理全部勾选文献，每篇记录支撑材料线索

### ④ 自由存储 + Excel 数据管理
- PDF / 支撑材料 / Excel 路径均可改到任意目录
- 提取的数据存 Excel，自选路径 / 工作表
- 数据管理页可预览、导出 CSV、下载整表

---

## 🤖 AI 模型配置

打开应用后，在**左侧边栏**填入 AI 配置（任意 OpenAI 兼容接口）：

| 配置项 | DeepSeek 示例 | 通义千问示例 | OpenAI 示例 |
|---|---|---|---|
| Base URL | `https://api.deepseek.com/v1` | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `https://api.openai.com/v1` |
| API Key | 你的 DeepSeek 密钥 | 你的 DashScope 密钥 | 你的 OpenAI 密钥 |
| 模型名 | `deepseek-chat` | `qwen-plus` | `gpt-4o-mini` |

配置保存到 `data/config.json`，**请勿泄露该文件**（含 API Key）。

---

## 📁 目录结构

解压后你的目录应该长这样：

```
文智汇_v1.0/
├── app.py                      ← Streamlit 主应用
├── 启动.bat                    ← 日常启动
├── 首次安装并启动.bat           ← 仅首次使用
├── README.md                   ← 本文件
├── requirements.txt            ← Python 依赖清单
├── assets/                     ← UI 图片
│   ├── logo.png
│   └── logo_src.png
└── literature_system/          ← 核心模块（12 个 .py）
    ├── __init__.py
    ├── models.py
    ├── searchers.py
    ├── downloader.py
    ├── pdf_reader.py
    ├── ai_client.py
    ├── excel_store.py
    ├── background.py
    ├── cn_searchers.py
    ├── journal_rank.py
    ├── search_history.py
    └── translator.py

首次启动后会自动创建：
└── data/                       ← 你的运行数据（可改路径）
    ├── config.json             ← AI 配置（含密钥）
    ├── pdfs/                   ← 下载的 PDF
    ├── supplementary/          ← 支撑材料
    └── 文献提取数据.xlsx        ← 默认数据表
```

---

## ❓ 常见问题

### Q1: 双击 `.bat` 后窗口闪退？
检查是否安装了 Anaconda 并勾选了"Add to PATH"。打开 cmd 输入 `conda --version` 看是否有输出。

### Q2: pip install 卡住或失败？
- 切到手机热点重试
- 或修改 `首次安装并启动.bat` 里的 `-i https://pypi.tuna.tsinghua.edu.cn/simple` 换其他源：
  - 阿里云：`https://mirrors.aliyun.com/pypi/simple/`
  - 中科大：`https://pypi.mirrors.ustc.edu.cn/simple/`

### Q3: 启动后浏览器没自动打开？
手动访问 `http://127.0.0.1:8501`（注意用 127.0.0.1，不要用 localhost）。

### Q4: 8501 端口被占用？
在 `启动.bat` 里把 `--server.port=8501` 改为其他端口（如 8502）。

### Q5: AI 接口调用失败？
- 检查左侧边栏的 API Key 是否正确
- 检查 Base URL 是否拼写正确（要带 `/v1`）
- DeepSeek / 通义都比 OpenAI 便宜很多，新手推荐

### Q6: 想要局域网内别人也能访问？
已默认监听 `0.0.0.0:8501`，对方用 `http://你的内网IP:8501` 即可。
查看本机 IP：cmd 输入 `ipconfig` 找 `IPv4 地址`。

---

## 📜 注意事项

- Semantic Scholar 匿名接口限流较严，偶发 429 会自动重试
- 非开放获取（付费墙）文献无法下载 PDF，请用"在线阅读"模式
- PDF 为扫描件（无文本层）时自动回退到在线阅读
- **AI 提取的数据建议人工核对后再用于科研**

---

## 🆕 版本

**v1.0** · 2026-10-08

如有使用问题，请联系开发者。