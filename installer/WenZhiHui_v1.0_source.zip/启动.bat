@echo off

echo ============================================
echo    WenZhiHui v1.0
echo ============================================

echo [1/4] Checking Anaconda ...
set "CONDA_EXE="
for %%p in (
    "C:\ProgramData\anaconda3"
    "C:\ProgramData\Anaconda3"
    "C:\Program Files\anaconda3"
    "%USERPROFILE%\anaconda3"
    "%LOCALAPPDATA%\Continuum\anaconda3"
) do (
    if exist "%%~p\Scripts\conda.exe" set "CONDA_EXE=%%~p\Scripts\conda.exe"
)
if "%CONDA_EXE%"=="" goto no_conda
echo   OK: %CONDA_EXE%
echo.

echo [2/4] Checking Python env wenZhiHui ...
"%CONDA_EXE%" run -n wenZhiHui python --version >nul 2>&1
if errorlevel 1 goto create_env
echo   OK: env exists
goto install_deps

:create_env
echo   Creating env (trying mirrors, 2-5 min) ...
echo   [1/3] Tsinghua mirror ...
"%CONDA_EXE%" create -n wenZhiHui python=3.11 -y --override-channels -c https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main
if not errorlevel 1 goto env_ok
echo   [2/3] USTC mirror ...
"%CONDA_EXE%" create -n wenZhiHui python=3.11 -y --override-channels -c https://mirrors.ustc.edu.cn/anaconda/pkgs/main
if not errorlevel 1 goto env_ok
echo   [3/3] conda defaults ...
"%CONDA_EXE%" create -n wenZhiHui python=3.11 -y --override-channels -c defaults
if not errorlevel 1 goto env_ok
goto create_failed

:env_ok
echo   OK: env ready
echo.

:install_deps
echo [3/4] Checking dependencies ...
"%CONDA_EXE%" run -n wenZhiHui python -c "import streamlit, pandas, fitz, docx; print('deps ok')" >nul 2>&1
if not errorlevel 1 goto deps_ok
echo   Installing dependencies (3-10 min) ...
echo   [1/2] Tsinghua PyPI ...
"%CONDA_EXE%" run -n wenZhiHui pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple --retries 5 --timeout 60
if not errorlevel 1 goto deps_ok
echo   [2/2] PyPI official ...
"%CONDA_EXE%" run -n wenZhiHui pip install -r requirements.txt --retries 5 --timeout 60
if not errorlevel 1 goto deps_ok
goto install_failed

:deps_ok
echo   OK: dependencies ready
echo.

echo [4/4] Starting service, browser will open ...
echo   (close this window to stop)
echo ============================================
cd /d "%~dp0"
start "" "http://127.0.0.1:8501"
"%CONDA_EXE%" run -n wenZhiHui streamlit run app.py --server.address=0.0.0.0 --server.port=8501 --browser.gatherUsageStats=false < NUL
goto end

:no_conda
echo.
echo   [ERROR] Anaconda not found!
echo   Please install Anaconda first: https://www.anaconda.com/download
echo   Check "Add Anaconda3 to my PATH" during install.
echo.
start "" "https://www.anaconda.com/download"
pause
exit /b 1

:create_failed
echo.
echo   [ERROR] Failed to create Python env!
echo   All 3 mirrors (Tsinghua / USTC / official) unreachable.
echo   Please try:
echo     1. Switch to phone hotspot and re-run
echo     2. If behind proxy, set HTTP_PROXY / HTTPS_PROXY
echo     3. Check antivirus is not blocking conda
echo.
echo   Or run manually:
echo     conda config --remove-key channels
echo     conda config --add channels defaults
echo     conda create -n wenZhiHui python=3.11 -y
echo ============================================
pause
exit /b 1

:install_failed
echo.
echo   [ERROR] Failed to install dependencies!
echo   Please check network (try phone hotspot) and re-run.
echo ============================================
pause
exit /b 1

:end
pause